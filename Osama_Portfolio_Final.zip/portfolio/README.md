# Osama Shawki — Personal Portfolio

A responsive, bilingual (Arabic/English) personal portfolio built with HTML, CSS and vanilla JavaScript. No build tools or paid services are required.

## Preview on Windows
1. Extract this ZIP file.
2. Open the `portfolio` folder.
3. Double-click `index.html` to open the site in your browser.

For a local development server, open a terminal in this folder and run:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Publish free with GitHub Pages
1. Sign in to GitHub and create a **public** repository named `osama-shawkii.github.io` (only use this name if it matches your GitHub username exactly; otherwise use any repository name).
2. Upload the contents of this `portfolio` folder to the repository root (make sure `index.html` is at the root).
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**, choose `main` and `/(root)`, then save.
5. GitHub will publish the site and show its URL in the Pages section. Publishing is not completed by this ZIP; it requires signing in to your own GitHub account.

## Before sharing publicly
- Add screenshots of your real projects to `assets/projects/` and replace the CSS-made preview cards with those images.
- Add public Figma/GitHub project links when available.
- Add a PDF CV if you want a download button.
- Confirm the exact training dates and wording, and update any skill you do not want to claim.
- The portfolio currently uses the contact details and background supplied for this draft. Review them before publishing.

## Included
- Arabic/English language toggle (remembers the selected language in the browser).
- Responsive layout and mobile navigation.
- Education, training, skills, projects, independent real-estate sales experience and contact sections.
- Project detail pop-ups.
